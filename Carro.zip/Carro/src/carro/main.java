

package carro;
/**
 *fecha 01/05/2021
 * Maira Otero
 * VERSION 8.1
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       formulario vehiculo=new formulario();
       
       vehiculo.setTitle("Datos Vehiculo");
       vehiculo.setVisible(true);
    }
    
}
