
package idioma;

/**
 * Maira Otero
 * fecha 01/05/2021
 * version 8.1
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        lenguaje ModuloTraductor=new lenguaje();
       
       ModuloTraductor.setTitle("Módulo Traductor");
       ModuloTraductor.setVisible(true);
    }
    
}
